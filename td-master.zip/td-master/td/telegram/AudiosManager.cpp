//
// Copyright Aliaksei Levin (levlam@telegram.org), Arseny Smirnov (arseny30@gmail.com) 2014-2026
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
#include "td/telegram/AudiosManager.h"

#include "td/telegram/AuthManager.h"
#include "td/telegram/DialogId.h"
#include "td/telegram/Document.h"
#include "td/telegram/DocumentsManager.h"
#include "td/telegram/FileReferenceManager.h"
#include "td/telegram/files/FileManager.h"
#include "td/telegram/files/FileType.h"
#include "td/telegram/Global.h"
#include "td/telegram/misc.h"
#include "td/telegram/PhotoFormat.h"
#include "td/telegram/secret_api.h"
#include "td/telegram/Td.h"
#include "td/telegram/telegram_api.h"

#include "td/actor/actor.h"

#include "td/utils/algorithm.h"
#include "td/utils/logging.h"
#include "td/utils/misc.h"
#include "td/utils/PathView.h"
#include "td/utils/SliceBuilder.h"
#include "td/utils/Status.h"

namespace td {

class UploadAudioFileQuery final : public Td::ResultHandler {
  Promise<Unit> promise_;
  FileUploadId file_upload_id_;
  bool is_url_ = false;
  bool was_uploaded_ = false;

 public:
  explicit UploadAudioFileQuery(Promise<Unit> &&promise) : promise_(std::move(promise)) {
  }

  void send(telegram_api::object_ptr<telegram_api::InputPeer> &&input_peer, FileUploadId file_upload_id, bool is_url,
            telegram_api::object_ptr<telegram_api::InputMedia> &&input_media) {
    CHECK(input_peer != nullptr);
    CHECK(input_media != nullptr);
    file_upload_id_ = file_upload_id;
    is_url_ = is_url;
    was_uploaded_ = FileManager::extract_was_uploaded(input_media);
    send_query(G()->net_query_creator().create(
        telegram_api::messages_uploadMedia(0, string(), std::move(input_peer), std::move(input_media))));
  }

  void on_result(BufferSlice packet) final {
    auto result_ptr = fetch_result<telegram_api::messages_uploadMedia>(packet);
    if (result_ptr.is_error()) {
      return on_error(result_ptr.move_as_error());
    }

    td_->audios_manager_->on_uploaded_audio_file(file_upload_id_, is_url_, result_ptr.move_as_ok(),
                                                 std::move(promise_));
  }

  void on_error(Status status) final {
    if (was_uploaded_) {
      CHECK(file_upload_id_.is_valid());
      auto bad_parts = FileManager::get_missing_file_parts(status);
      if (!bad_parts.empty()) {
        // TODO td_->audios_manager_->on_upload_audio_file_parts_missing(file_upload_id_, std::move(bad_parts));
        // return;
      } else {
        td_->file_manager_->delete_partial_remote_location_if_needed(file_upload_id_, status);
      }
    } else if (FileReferenceManager::is_file_reference_error(status)) {
      LOG(ERROR) << "Receive file reference error for UploadAudioFileQuery";
    }
    td_->file_manager_->cancel_upload(file_upload_id_);
    promise_.set_error(std::move(status));
  }
};

class AudiosManager::UploadAudioFileCallback final : public FileManager::UploadCallback {
 public:
  void on_upload_ok(FileUploadId file_upload_id, telegram_api::object_ptr<telegram_api::InputFile> input_file) final {
    send_closure_later(G()->audios_manager(), &AudiosManager::on_upload_audio_file, file_upload_id,
                       std::move(input_file));
  }

  void on_upload_error(FileUploadId file_upload_id, Status error) final {
    send_closure_later(G()->audios_manager(), &AudiosManager::on_upload_audio_file_error, file_upload_id,
                       std::move(error));
  }
};

AudiosManager::AudiosManager(Td *td, ActorShared<> parent) : td_(td), parent_(std::move(parent)) {
  upload_audio_file_callback_ = std::make_shared<UploadAudioFileCallback>();
}

AudiosManager::~AudiosManager() {
  Scheduler::instance()->destroy_on_scheduler(G()->get_gc_scheduler_id(), audios_);
}

void AudiosManager::tear_down() {
  parent_.reset();
}

int32 AudiosManager::get_audio_duration(FileId file_id) const {
  const auto *audio = get_audio(file_id);
  if (audio == nullptr) {
    return 0;
  }
  return audio->duration;
}

tl_object_ptr<td_api::audio> AudiosManager::get_audio_object(FileId file_id) const {
  if (!file_id.is_valid()) {
    return nullptr;
  }

  auto audio = get_audio(file_id);
  CHECK(audio != nullptr);

  vector<td_api::object_ptr<td_api::thumbnail>> album_covers;
  if (!td_->auth_manager_->is_bot()) {
    auto add_album_cover = [&](bool is_small, int32 width, int32 height) {
      auto r_file_id =
          td_->file_manager_->get_audio_thumbnail_file_id(audio->title, audio->performer, is_small, DialogId());
      if (r_file_id.is_ok()) {
        album_covers.emplace_back(
            td_api::make_object<td_api::thumbnail>(td_api::make_object<td_api::thumbnailFormatJpeg>(), width, height,
                                                   td_->file_manager_->get_file_object(r_file_id.move_as_ok())));
      }
    };

    add_album_cover(true, 100, 100);
    add_album_cover(false, 600, 600);
  }
  return make_tl_object<td_api::audio>(
      audio->duration, audio->title, audio->performer, audio->file_name, audio->mime_type,
      get_minithumbnail_object(audio->minithumbnail),
      get_thumbnail_object(td_->file_manager_.get(), audio->thumbnail, PhotoFormat::Jpeg), std::move(album_covers),
      td_->file_manager_->get_file_object(file_id));
}

td_api::object_ptr<td_api::notificationSound> AudiosManager::get_notification_sound_object(FileId file_id) const {
  if (!file_id.is_valid()) {
    return nullptr;
  }

  auto audio = get_audio(file_id);
  CHECK(audio != nullptr);
  auto file_view = td_->file_manager_->get_file_view(file_id);
  CHECK(!file_view.empty());
  CHECK(file_view.get_type() == FileType::Ringtone);
  auto full_remote_location = file_view.get_full_remote_location();
  CHECK(full_remote_location != nullptr);
  auto document_id = full_remote_location->get_id();
  auto title = audio->title;
  if (title.empty() && !audio->file_name.empty()) {
    title = PathView(audio->file_name).file_name_without_extension().str();
  }
  return td_api::make_object<td_api::notificationSound>(document_id, audio->duration, audio->date, title,
                                                        audio->performer, td_->file_manager_->get_file_object(file_id));
}

td_api::object_ptr<td_api::notificationSounds> AudiosManager::get_notification_sounds_object(
    const vector<FileId> &file_ids) const {
  return td_api::make_object<td_api::notificationSounds>(
      transform(file_ids, [this](FileId file_id) { return get_notification_sound_object(file_id); }));
}

FileId AudiosManager::on_get_audio(unique_ptr<Audio> new_audio, bool replace) {
  auto file_id = new_audio->file_id;
  CHECK(file_id.is_valid());
  LOG(INFO) << "Receive audio " << file_id;
  auto &a = audios_[file_id];
  if (a == nullptr) {
    a = std::move(new_audio);
  } else if (replace) {
    CHECK(a->file_id == new_audio->file_id);
    if (a->mime_type != new_audio->mime_type || a->duration != new_audio->duration || a->title != new_audio->title ||
        a->performer != new_audio->performer || a->file_name != new_audio->file_name || a->date != new_audio->date ||
        a->minithumbnail != new_audio->minithumbnail || a->thumbnail != new_audio->thumbnail) {
      LOG(DEBUG) << "Audio " << file_id << " info has changed";
      a->mime_type = std::move(new_audio->mime_type);
      a->duration = new_audio->duration;
      a->title = std::move(new_audio->title);
      a->performer = std::move(new_audio->performer);
      a->file_name = std::move(new_audio->file_name);
      a->date = new_audio->date;
      a->minithumbnail = std::move(new_audio->minithumbnail);
      a->thumbnail = std::move(new_audio->thumbnail);
    }
  }

  return file_id;
}

const AudiosManager::Audio *AudiosManager::get_audio(FileId file_id) const {
  return audios_.get_pointer(file_id);
}

FileId AudiosManager::dup_audio(FileId new_id, FileId old_id) {
  const Audio *old_audio = get_audio(old_id);
  CHECK(old_audio != nullptr);
  auto &new_audio = audios_[new_id];
  if (new_audio != nullptr) {
    return new_id;
  }
  new_audio = make_unique<Audio>(*old_audio);
  new_audio->file_id = new_id;
  return new_id;
}

void AudiosManager::merge_audios(FileId new_id, FileId old_id) {
  CHECK(old_id.is_valid() && new_id.is_valid());
  CHECK(new_id != old_id);

  LOG(INFO) << "Merge audios " << new_id << " and " << old_id;
  const Audio *old_ = get_audio(old_id);
  CHECK(old_ != nullptr);

  const auto *new_ = get_audio(new_id);
  if (new_ == nullptr) {
    dup_audio(new_id, old_id);
  } else {
    if (!old_->mime_type.empty() && old_->mime_type != new_->mime_type) {
      LOG(INFO) << "Audio has changed: mime_type = (" << old_->mime_type << ", " << new_->mime_type << ")";
    }
  }
  LOG_STATUS(td_->file_manager_->merge(new_id, old_id));
}

string AudiosManager::get_audio_search_text(FileId file_id) const {
  auto audio = get_audio(file_id);
  CHECK(audio != nullptr);
  return PSTRING() << audio->file_name << " " << audio->title << " " << audio->performer;
}

FileId AudiosManager::get_audio_thumbnail_file_id(FileId file_id) const {
  auto audio = get_audio(file_id);
  CHECK(audio != nullptr);
  return audio->thumbnail.file_id;
}

void AudiosManager::append_audio_album_cover_file_ids(FileId file_id, vector<FileId> &file_ids) const {
  if (td_->auth_manager_->is_bot()) {
    return;
  }
  auto audio = get_audio(file_id);
  CHECK(audio != nullptr);

  auto append_album_cover = [&](bool is_small) {
    auto r_file_id =
        td_->file_manager_->get_audio_thumbnail_file_id(audio->title, audio->performer, is_small, DialogId());
    if (r_file_id.is_ok()) {
      file_ids.push_back(r_file_id.ok());
    }
  };

  append_album_cover(true);
  append_album_cover(false);
}

void AudiosManager::delete_audio_thumbnail(FileId file_id) {
  auto &audio = audios_[file_id];
  CHECK(audio != nullptr);
  audio->thumbnail = PhotoSize();
}

void AudiosManager::create_audio(FileId file_id, string minithumbnail, PhotoSize thumbnail, string file_name,
                                 string mime_type, int32 duration, string title, string performer, int32 date,
                                 bool replace) {
  auto a = make_unique<Audio>();
  a->file_id = file_id;
  a->file_name = std::move(file_name);
  a->mime_type = std::move(mime_type);
  a->duration = max(duration, 0);
  a->title = std::move(title);
  a->performer = std::move(performer);
  a->date = date;
  if (!td_->auth_manager_->is_bot()) {
    a->minithumbnail = std::move(minithumbnail);
  }
  a->thumbnail = std::move(thumbnail);
  on_get_audio(std::move(a), replace);
}

SecretInputMedia AudiosManager::get_secret_input_media(
    FileId audio_file_id, telegram_api::object_ptr<telegram_api::InputEncryptedFile> input_file, const string &caption,
    BufferSlice thumbnail, int32 layer) const {
  auto *audio = get_audio(audio_file_id);
  CHECK(audio != nullptr);
  auto file_view = td_->file_manager_->get_file_view(audio_file_id);
  if (!file_view.is_encrypted_secret() || file_view.encryption_key().empty()) {
    return SecretInputMedia{};
  }
  const auto *main_remote_location = file_view.get_main_remote_location();
  if (main_remote_location != nullptr) {
    input_file = main_remote_location->as_input_encrypted_file();
  }
  if (!input_file) {
    return SecretInputMedia{};
  }
  if (audio->thumbnail.file_id.is_valid() && thumbnail.empty()) {
    return SecretInputMedia{};
  }
  vector<secret_api::object_ptr<secret_api::DocumentAttribute>> attributes;
  if (!audio->file_name.empty()) {
    attributes.push_back(secret_api::make_object<secret_api::documentAttributeFilename>(audio->file_name));
  }
  attributes.push_back(secret_api::make_object<secret_api::documentAttributeAudio>(
      0, false, audio->duration, audio->title, audio->performer, BufferSlice()));

  return {std::move(input_file),
          std::move(thumbnail),
          audio->thumbnail.dimensions,
          audio->mime_type,
          file_view,
          std::move(attributes),
          caption,
          layer};
}

tl_object_ptr<telegram_api::InputMedia> AudiosManager::get_input_media(
    FileId file_id, telegram_api::object_ptr<telegram_api::InputFile> input_file,
    telegram_api::object_ptr<telegram_api::InputFile> input_thumbnail) const {
  auto file_view = td_->file_manager_->get_file_view(file_id);
  if (file_view.is_encrypted()) {
    return nullptr;
  }
  const auto *main_remote_location = file_view.get_main_remote_location();
  if (main_remote_location != nullptr && !main_remote_location->is_web() && input_file == nullptr) {
    return telegram_api::make_object<telegram_api::inputMediaDocument>(
        0, false, main_remote_location->as_input_document(), nullptr, 0, 0, string());
  }
  const auto *url = file_view.get_url();
  if (url != nullptr) {
    return telegram_api::make_object<telegram_api::inputMediaDocumentExternal>(0, false, *url, 0, nullptr, 0);
  }

  if (input_file != nullptr) {
    const Audio *audio = get_audio(file_id);
    CHECK(audio != nullptr);

    vector<telegram_api::object_ptr<telegram_api::DocumentAttribute>> attributes;
    attributes.push_back(telegram_api::make_object<telegram_api::documentAttributeAudio>(
        0, false, audio->duration, audio->title, audio->performer, BufferSlice()));
    if (!audio->file_name.empty()) {
      attributes.push_back(telegram_api::make_object<telegram_api::documentAttributeFilename>(audio->file_name));
    }
    string mime_type = audio->mime_type;
    if (!begins_with(mime_type, "audio/")) {
      mime_type = "audio/mpeg";
    }
    return telegram_api::make_object<telegram_api::inputMediaUploadedDocument>(
        0, false, false, false, std::move(input_file), std::move(input_thumbnail), mime_type, std::move(attributes),
        vector<telegram_api::object_ptr<telegram_api::InputDocument>>(), nullptr, 0, 0);
  } else {
    CHECK(main_remote_location == nullptr);
  }

  return nullptr;
}

void AudiosManager::upload_audio(td_api::object_ptr<td_api::inputAudio> &&input_audio, Promise<FileId> &&promise) {
  if (input_audio == nullptr) {
    return promise.set_error(400, "Audio must be non-empty");
  }
  if (!clean_input_string(input_audio->title_) || !clean_input_string(input_audio->performer_)) {
    return promise.set_error(400, "Strings must be encoded in UTF-8");
  }
  auto audio = std::move(input_audio->audio_);
  TRY_RESULT_PROMISE(promise, file_id,
                     td_->file_manager_->get_input_file_id(FileType::Audio, audio, DialogId(), false, false));
  CHECK(file_id.is_valid());

  FileView file_view = td_->file_manager_->get_file_view(file_id);
  if (file_view.is_encrypted()) {
    return promise.set_error(400, "Can't use encrypted file");
  }

  const auto *main_remote_location = file_view.get_main_remote_location();
  if (main_remote_location != nullptr && main_remote_location->is_web()) {
    return promise.set_error(400, "Can't use web file as an audio");
  }

  create_audio(file_id, string(), PhotoSize(), string(), string(), input_audio->duration_, input_audio->title_,
               input_audio->performer_, 0, false);
  if (main_remote_location != nullptr) {
    dup_audio(file_view.get_main_file_id(), file_id);
    return promise.set_value(std::move(file_id));
  }

  auto upload_promise = PromiseCreator::lambda([file_id, promise = std::move(promise)](Result<Unit> &&result) mutable {
    if (result.is_error()) {
      return promise.set_error(result.move_as_error());
    }
    promise.set_value(std::move(file_id));
  });
  if (file_view.has_url()) {
    do_upload_audio_file({file_id, FileManager::get_internal_upload_id()}, nullptr, std::move(upload_promise));
  } else {
    upload_audio_file(file_id, std::move(upload_promise));
  }
}

void AudiosManager::reupload_audio(FileId file_id, Promise<Unit> &&promise) {
  FileUploadId file_upload_id{file_id, FileManager::get_internal_upload_id()};
  CHECK(file_upload_id.is_valid());
  being_uploaded_audio_files_[file_upload_id] = std::move(promise);
  LOG(INFO) << "Ask to reupload audio " << file_upload_id;
  td_->file_manager_->resume_upload(file_upload_id, {-1}, upload_audio_file_callback_, 2, 0);
}

void AudiosManager::upload_audio_file(FileId file_id, Promise<Unit> &&promise) {
  CHECK(get_input_media(file_id, nullptr, nullptr) == nullptr);

  FileUploadId file_upload_id{file_id, FileManager::get_internal_upload_id()};
  CHECK(file_upload_id.is_valid());
  being_uploaded_audio_files_[file_upload_id] = std::move(promise);
  LOG(INFO) << "Ask to upload audio " << file_upload_id;
  td_->file_manager_->upload(file_upload_id, upload_audio_file_callback_, 2, 0);
}

void AudiosManager::on_upload_audio_file(FileUploadId file_upload_id,
                                         telegram_api::object_ptr<telegram_api::InputFile> input_file) {
  if (G()->close_flag()) {
    return;
  }
  LOG(INFO) << "Audio " << file_upload_id << " has been uploaded";

  auto it = being_uploaded_audio_files_.find(file_upload_id);
  CHECK(it != being_uploaded_audio_files_.end());
  auto promise = std::move(it->second);
  being_uploaded_audio_files_.erase(it);

  do_upload_audio_file(file_upload_id, std::move(input_file), std::move(promise));
}

void AudiosManager::on_upload_audio_file_error(FileUploadId file_upload_id, Status status) {
  if (G()->close_flag()) {
    return;
  }

  LOG(WARNING) << "Audio " << file_upload_id << " has upload error " << status;
  CHECK(status.is_error());

  auto it = being_uploaded_audio_files_.find(file_upload_id);
  CHECK(it != being_uploaded_audio_files_.end());
  auto promise = std::move(it->second);
  being_uploaded_audio_files_.erase(it);

  promise.set_error(status.code() > 0 ? status.code() : 500,
                    status.message());  // TODO CHECK that status has always a code
}

void AudiosManager::do_upload_audio_file(FileUploadId file_upload_id,
                                         telegram_api::object_ptr<telegram_api::InputFile> &&input_file,
                                         Promise<Unit> &&promise) {
  TRY_STATUS_PROMISE(promise, G()->close_status());

  bool had_input_file = input_file != nullptr;
  auto input_media = get_input_media(file_upload_id.get_file_id(), std::move(input_file), nullptr);
  CHECK(input_media != nullptr);
  if (had_input_file && !FileManager::extract_was_uploaded(input_media)) {
    // if we had InputFile, but has failed to use it for input_media, then we need to immediately cancel file upload
    // so the next upload with the same file can succeed
    td_->file_manager_->cancel_upload(file_upload_id);
  }

  td_->create_handler<UploadAudioFileQuery>(std::move(promise))
      ->send(telegram_api::make_object<telegram_api::inputPeerSelf>(), file_upload_id, !had_input_file,
             std::move(input_media));
}

void AudiosManager::on_uploaded_audio_file(FileUploadId file_upload_id, bool is_url,
                                           telegram_api::object_ptr<telegram_api::MessageMedia> media,
                                           Promise<Unit> &&promise) {
  CHECK(media != nullptr);
  LOG(INFO) << "Receive uploaded audio file " << to_string(media);
  if (media->get_id() != telegram_api::messageMediaDocument::ID) {
    td_->file_manager_->delete_partial_remote_location(file_upload_id);
    return promise.set_error(400, "Can't upload audio file: wrong file type");
  }

  auto message_document = telegram_api::move_object_as<telegram_api::messageMediaDocument>(media);
  auto document_ptr = std::move(message_document->document_);
  int32 document_id = document_ptr->get_id();
  if (document_id == telegram_api::documentEmpty::ID) {
    td_->file_manager_->delete_partial_remote_location(file_upload_id);
    return promise.set_error(400, "Can't upload audio file: empty file");
  }
  CHECK(document_id == telegram_api::document::ID);

  auto parsed_document = td_->documents_manager_->on_get_document(
      telegram_api::move_object_as<telegram_api::document>(document_ptr), DialogId(), false, false);
  if (parsed_document.type != Document::Type::Audio) {
    td_->file_manager_->delete_partial_remote_location(file_upload_id);
    return promise.set_error(400, "Wrong file type");
  }

  auto file_id = file_upload_id.get_file_id();
  if (parsed_document.file_id != file_id) {
    // must not delete the old audio, because the file_id could be used for simultaneous URL uploads
    merge_audios(parsed_document.file_id, file_id);
  }
  td_->file_manager_->cancel_upload(file_upload_id);
  promise.set_value(Unit());
}

}  // namespace td
